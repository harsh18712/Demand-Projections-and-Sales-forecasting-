# SalesPulse: Demand Projection & Sales Forecasting

Forecasts 12 months of product demand and turns it into a monthly inventory plan.

**Stack:** Python, pandas, statsmodels, scikit-learn, matplotlib, Jupyter

## Pipeline
1. **Data:** 72 months (2019-2024) of synthetic unit sales with trend + festive seasonality + noise
2. **EDA:** line plot, monthly averages, seasonal decomposition
3. **Split:** train 2019-2023, test 2024 (time-based, no shuffling)
4. **Models:** Naive, Seasonal Naive, Moving Average, Linear Regression (trend + month dummies), Holt-Winters
5. **Evaluation:** MAE, RMSE, MAPE on the 2024 test set
6. **Forecast:** best model retrained on all data, 2025 forecast with 95% range
7. **Demand projection:** safety stock = Z x sigma x sqrt(lead time), target stock per month

## Results (2024 test set)
| Model | MAPE % |
|---|---|
| Holt-Winters | 1.78 |
| Linear Regression | 2.93 |
| Seasonal Naive | 8.22 |
| Naive | 16.70 |
| Moving Avg (3) | 20.08 |

2025 projection: ~24,100 units (about 8.6% above 2024), peak in November.

## Files
- `SalesPulse_Demand_Forecasting.ipynb` : full notebook with outputs
- `sales_data.csv`, `model_comparison.csv`, `demand_plan_2025.csv`
- `01-04_*.png` : charts

## Limitations / next steps
Synthetic data, single product, no price/promo variables. Next: real dataset, promotions as features, SARIMA/Prophet, per-product forecasts.

---

## Interview cheat sheet

**30-second pitch:**
"I built a sales forecasting pipeline that predicts the next 12 months of demand and converts it into a stock plan. I compared five models against simple baselines on a held-out year, picked Holt-Winters on MAPE, and used its forecast error to compute safety stock per month."

**Likely questions:**
- **Why Holt-Winters?** Data has trend and yearly seasonality; Holt-Winters models both and weights recent data more. It also beat the baselines by a wide margin.
- **Why baselines?** A fancy model is only useful if it beats "same month last year". Seasonal Naive was my benchmark.
- **Why not a random train/test split?** Time series: random split leaks future into training. I held out the last 12 months.
- **Why MAPE?** Percentage error is easy to explain to business teams. I also report MAE and RMSE since MAPE breaks near zero demand.
- **Why multiplicative seasonality?** Seasonal swings grow as sales grow (the Oct-Nov peak is larger in later years).
- **Is 1.78% MAPE realistic?** No, and I say so upfront: the data is synthetic with clean patterns. Real data would be noisier (expect 10-20%). The point is the method, and the code runs on any CSV with `date` and `units`.
- **What is safety stock?** Buffer for forecast error. Z = 1.65 gives ~95% service level; sigma is residual std; scaled by sqrt(lead time).
- **How would you improve it?** Real data, promo/holiday/price features, SARIMA or Prophet, rolling-window cross-validation, per-SKU forecasts.
- **Link to your mining work?** Same time-series toolkit (ADF/KPSS, seasonality, ARIMA) I used for mine production forecasting.

**Resume bullets (pick 2-3):**
- Built an end-to-end demand forecasting pipeline in Python (pandas, statsmodels) on 6 years of monthly sales; compared 5 models against naive baselines using MAE, RMSE and MAPE on a held-out year.
- Selected Holt-Winters (MAPE 1.8% vs 8.2% for seasonal naive) and projected 12-month demand with 95% intervals.
- Converted forecasts into a monthly inventory plan using safety-stock calculation (95% service level), projecting ~8.6% YoY demand growth with an Oct-Nov peak.
